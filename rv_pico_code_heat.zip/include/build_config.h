#pragma once
// generated at build time; placeholder for IDE
